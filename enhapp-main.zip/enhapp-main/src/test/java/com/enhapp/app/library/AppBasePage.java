package com.enhapp.app.library;

import com.enhapp.app.reportsconfig.AppTestListeners;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

public class AppBasePage extends AppTestListeners {
    public AppiumDriver<MobileElement> driver;
    public WebDriverWait wait;
    public JavascriptExecutor executor;


    public AppBasePage(AppiumDriver<MobileElement> driver)
    {
        this.driver=driver;
        wait=new WebDriverWait(driver, 30);
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public void waitAndClickElement(MobileElement element)
    {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();
            Reporter.log(" Element Clicked",true);
        }catch (Exception ex)
        {
            ex.printStackTrace();
            Reporter.log("Element not Clicked or Not Found",true);
            Assert.fail();
        }
    }

    public void waitAndClickElementWithSkip(MobileElement element)
    {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();
            Reporter.log(" Element Clicked",true);
        }catch (Exception ex)
        {
            //Not printing to Stacktrace
            //ex.printStackTrace();
            Reporter.log("Element Not Found",true);
        }
    }

    public void verifyElement(MobileElement element, String elementName) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            Reporter.log(elementName + " is present ", true);
        } catch (Exception e) {
            Reporter.log(elementName + " not found ", true);
            Assert.fail();
        }
    }
}
