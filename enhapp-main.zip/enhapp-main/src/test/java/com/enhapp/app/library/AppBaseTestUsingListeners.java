package com.enhapp.app.library;

import com.enhapp.app.reportsconfig.AppTestListeners;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.json.JSONObject;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import static com.enhapp.app.library.AppConstants.REMOTE_CONFIGURATION;


public class AppBaseTestUsingListeners extends AppTestListeners implements ITest {

    public AppiumDriver<MobileElement> driver;
    public DesiredCapabilities caps;
    public JSONObject deviceObj;
    public Properties prop;
    public static String DeviceName;
    private final ThreadLocal<String> testName = new ThreadLocal<>();

    @Parameters({"deviceID"})
    @BeforeClass
    public void setUp(String deviceID) throws MalformedURLException {
        setDeviceName(deviceID);
        deviceObj = new JSONObject(JsonParser.parse("Devices.json").getJSONObject(deviceID).toString());
        prop = AppPropertiesReader.readPropertiesFile(REMOTE_CONFIGURATION);
        if(deviceID.equals("POCO-F1")) {
            caps = new DesiredCapabilities();
            caps.setCapability("deviceName", deviceObj.getString("deviceName"));
            //caps.setCapability("udid", prop.getProperty("udid")); //Give Device ID of your mobile phone
            caps.setCapability("platformName", deviceObj.getString("platformName"));
            caps.setCapability("platformVersion", deviceObj.getString("platformVersion"));
            caps.setCapability("appPackage", deviceObj.getString("appPackage"));
            caps.setCapability("appActivity", deviceObj.getString("appActivity"));
            caps.setCapability("noReset", deviceObj.getString("noReset"));
            caps.setCapability("automationName", deviceObj.getString("automationName"));
            caps.setCapability("adbExecTimeout", deviceObj.getString("adbExecTimeout"));
            URL url = new URL(deviceObj.getString("localDeviceUrl"));
            driver = new AppiumDriver<>(url, caps);
        }else
        {
            caps = new DesiredCapabilities();
            caps.setCapability("app",  deviceObj.getString("app"));
            caps.setCapability("device",  deviceObj.getString("device"));
            caps.setCapability("os_version", deviceObj.getString("os_version"));
            caps.setCapability("project",  deviceObj.getString("project"));
            caps.setCapability("build",  deviceObj.getString("build"));
            caps.setCapability("name",  deviceObj.getString("name"));
            caps.setCapability("browserstack.user", prop.getProperty("browserstackUser"));
            caps.setCapability("browserstack.key", prop.getProperty("browserstackKey"));
            URL url = new URL(prop.getProperty("browserstackUrl"));

            if(deviceID.equals("Android")){
                driver = new AndroidDriver<>(url, caps);
            }else if(deviceID.equals("IOS")){
                driver = new IOSDriver<>(url, caps);
            }else Reporter.log("Invalid Device ID");
        }
    }

    @BeforeMethod
    public void BeforeMethod(Object[] testData, ITestContext ctx) {
        if (testData.length > 0) {
            testName.set(testData[0]+ "--" + testData[1]);
            ctx.setAttribute("testName"," :: "+ testName.get());
        } else
            ctx.setAttribute("testName", "");
    }

    @AfterClass
    public void tearDown ()
    {
        driver.quit();
    }

    @Override
    public String getTestName() {
        return testName.get();
    }

    public static void setDeviceName(String deviceID) {
        DeviceName = deviceID ;

    }

    public String getDeviceName() {
        return DeviceName;

    }

}
