package com.enhapp.app.tests;

import com.enhapp.app.library.AppBaseTestUsingListeners;
import com.enhapp.app.library.AppConstants;
import com.enhapp.app.pom.AppLoginPagePO;
import org.testng.annotations.Test;


public class AppTest extends AppBaseTestUsingListeners implements AppConstants {

    @Test(priority = 1,description = "Verify Login Screen Elements")
    public void test_Login_Screen_Verification()
    {
        AppLoginPagePO loginPagePO=new AppLoginPagePO(driver);
        loginPagePO.loginPageVerify();

    }

    @Test(priority = 2,description = "Verify Login Functionality")
    public void test_Login_Verification()
    {
        AppLoginPagePO loginPagePO=new AppLoginPagePO(driver);
        loginPagePO.loginFunction();

    }
}
