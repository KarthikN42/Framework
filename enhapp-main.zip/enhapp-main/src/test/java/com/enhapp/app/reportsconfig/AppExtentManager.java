package com.enhapp.app.reportsconfig;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AppExtentManager {

    public static ExtentReports createInstance(){
         String fileName=getReportName();
         String directory=System.getProperty("user.dir")+"/reports/"+getDate()+"/";
         new File(directory).mkdirs();
         String path=directory+fileName;
         ExtentSparkReporter htmlReporter=new ExtentSparkReporter(path);

         htmlReporter.config().setEncoding("utf-8");
         htmlReporter.config().setDocumentTitle("Enhapp Automation Report");
         htmlReporter.config().setReportName("Automation Test Results");
         htmlReporter.config().setTheme(Theme.DARK);


        ExtentReports reports = new ExtentReports();
         reports.attachReporter(htmlReporter);
         reports.setSystemInfo("Hostname", "Localhost,Browser Stack");
         //reports.setSystemInfo("Browser", "Google Chrome");
         reports.setSystemInfo("Tester Name", "Anandu");

         return reports;
     }

     public static String getReportName()
     {
         Date date=new Date();
         String fileName="Automation Report_"+date.toString().replace(":","_").replace(" ","_")+".html";
         return fileName;
     }
    public static String getDate()
    {
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd_MM_Y");
        String time = dateFormat.format(now);
        return time;
    }

}
