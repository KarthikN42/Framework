package com.enhapp.app.library;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class AppPropertiesReader {
    public static Properties readPropertiesFile(String fileName) {
        Properties prop = null;
        try (FileInputStream fis = new FileInputStream(fileName)) {
            prop = new Properties();
            prop.load(fis);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return prop;
    }
}
