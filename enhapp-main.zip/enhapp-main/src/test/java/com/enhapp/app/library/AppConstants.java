package com.enhapp.app.library;

public interface AppConstants {

    String EXCEL_PATH = "./src/test/resources/TestData.xlsx";
    String CONFIGURATION_PATH = "./src/test/resources/localDevices.properties";
    String REMOTE_CONFIGURATION = "./src/test/resources/remoteEnvironment.properties";
    String APP_LOGIN_SHEET_NAME = "AppLogin";
    String APP_LOGIN_USERNAME = AppExcelHandling.getCellValue(EXCEL_PATH, APP_LOGIN_SHEET_NAME, 1, 0);
    String APP_LOGIN_PASSWORD = AppExcelHandling.getCellValue(EXCEL_PATH, APP_LOGIN_SHEET_NAME, 1, 1);
}