package com.enhapp.app.pom;

import com.enhapp.app.library.AppBasePage;
import com.enhapp.app.library.AppConstants;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;


public class AppLoginPagePO extends AppBasePage implements AppConstants {
    public AppLoginPagePO(AppiumDriver<MobileElement> driver) {
        super(driver);
    }
    @iOSXCUITFindBy(iOSNsPredicate = "name = 'Allow'")
    private MobileElement AllowNotify;

    @AndroidFindBy(xpath = "//*[@text='Login']")
    @iOSXCUITFindBy(iOSNsPredicate = "label contains 'Login'")
    private MobileElement loginBtn;

    @AndroidFindBy(xpath = "//*[@resource-id = 'Input_UsernameVal']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[1]")
    private MobileElement userNameTxtBx;

    @AndroidFindBy(xpath ="//*[@resource-id = 'Input_PasswordVal']")
    @iOSXCUITFindBy(className = "XCUIElementTypeSecureTextField")
    private MobileElement passwordTxtBx;


    @AndroidFindBy(xpath = "//span[text()=' Logout ']")
    private MobileElement logoutBtn;

    public void loginPageVerify() {
        //waitAndClickElementWithSkip(AllowNotify);
        waitAndClickElement(loginBtn);
        verifyElement(userNameTxtBx,"Login Email Input Field");
        verifyElement(passwordTxtBx,"Login password Input Field");
        verifyElement(loginBtn,"Login Button");
    }

    public void loginFunction() {
        userNameTxtBx.sendKeys(APP_LOGIN_USERNAME);
        passwordTxtBx.sendKeys(APP_LOGIN_PASSWORD);
        loginBtn.click();
        //verifyElement(logoutBtn,"Logout Button"); // to verify logout element present for success login
    }

}
